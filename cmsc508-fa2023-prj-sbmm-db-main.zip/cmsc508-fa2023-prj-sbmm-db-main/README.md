## Deliverable 4
Deliverable 4. This assignment is the 4th deliverable for the semester long database project. The project domain, challenges, and proposed database solution were all provided in the deliver4.qmd file 

# Running the program
* Clone the appropriate repository
* Cd into cloned repository 
* Open deliver4.qmd

# Project Overview 
* View/Modify pitch/design video, Problem Description, Database Design, Project Management, etc as needed
* Render the file with the command "quarto render deliver4.qmd"
* edit as needed.

deliver4.html: cmsc508-fa2023-prj-sbmm-db/reports/deliver4.html
Pitch Video: https://vcu.mediaspace.kaltura.com/media/Noah+McCain%27s+Personal+Meeting+Room/1_gtk92bqr
Design Video: https://vcu.mediaspace.kaltura.com/media/Noah+McCain%27s+Zoom+Meeting/1_rfx6ozcr 
Github repo: https://github.com/cmsc-vcu/cmsc508-fa2023-prj-sbmm-db.git

## Deliverable 7. 
This assignment is the 7th deliverable for the semester long database project. The project domain, challenges, and proposed database solution, API definition, Implementation, and Refelctions are all provided in the deliver7.qmd file. The source code which contains deliver7-ddl.sql, api.py, and apitest.py which define our database data, api, and testing of the API.

# Running the program
* Clone the appropriate repository
* Cd into cloned repository 
* Open deliver7.qmd or any of the three source code files. 

# Project Overview 
* View/Modify final design video, Problem Description, Database Design, Project Management, API Solution, Implementation, and reflections as needed. The source code is also available to be modified. Look at deliver7-ddl.sql, api.py, or apitest.py
* Render the file with the command "quarto render deliver7.qmd"
* edit as needed.

Link to HTML File: https://github.com/cmsc-vcu/cmsc508-fa2023-prj-sbmm-db/blob/main/reports/deliver7.html
