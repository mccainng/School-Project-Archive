-- DDL.sql

DROP TABLE IF EXISTS Matchmaking_Data;
DROP TABLE IF EXISTS Gameplay_Metrics;
DROP TABLE IF EXISTS Interaction_Data;
DROP TABLE IF EXISTS Player_Info;

-- Create Player_Info table
CREATE TABLE Player_Info (
    Player_Id INT PRIMARY KEY,
    Player_Name VARCHAR(255) NOT NULL
);

-- Create Matchmaking_Data table
CREATE TABLE Matchmaking_Data (
    Match_ID INT PRIMARY KEY,
    match_outcome VARCHAR(255) NOT NULL,
    win_loss_ratio DOUBLE NOT NULL,
    Player_Id INT,
    FOREIGN KEY (Player_Id) REFERENCES Player_Info(Player_Id)
);

-- Create Gameplay_Metrics table
CREATE TABLE Gameplay_Metrics (
    Metrics_ID INT PRIMARY KEY,
    playtime INT NOT NULL,
    level INT NOT NULL,
    Player_Id INT,
    FOREIGN KEY (Player_Id) REFERENCES Player_Info(Player_Id)
);

-- Create Interaction_Data table
CREATE TABLE Interaction_Data (
    interaction_ID INT PRIMARY KEY,
    interaction_type VARCHAR(255) NOT NULL,
    feedback_rating INT NOT NULL,
    Player_Id INT,
    FOREIGN KEY (Player_Id) REFERENCES Player_Info(Player_Id)
);

-- Sample data for Player_Info table
INSERT INTO Player_Info (Player_Id, Player_Name) VALUES
(1, 'Player1'),
(2, 'Player2'),
(3, 'Player3'),
(4, 'Player4'),
(5, 'Player5');

-- Sample data for Matchmaking_Data table
INSERT INTO Matchmaking_Data (Match_ID, match_outcome, win_loss_ratio, Player_Id) VALUES
(1, 'Win', 2.3, 1),
(2, 'Loss', 1.8, 2),
(3, 'Win', 3.1, 3),
(4, 'Loss', 1.2, 4),
(5, 'Win', 1.5, 5);

-- Sample data for Gameplay_Metrics table
INSERT INTO Gameplay_Metrics (Metrics_ID, playtime, level, Player_Id) VALUES
(1, 120, 10, 1),
(2, 200, 1, 2),
(3, 100, 150, 3),
(4, 400, 80, 4),
(5, 560, 76, 5);

-- Sample data for Interaction_Data table
INSERT INTO Interaction_Data (interaction_ID, interaction_type, feedback_rating, Player_Id) VALUES
(1, 'Bug Report', 7, 1),
(2, 'Suggestion', 9, 2),
(3, 'Feedback', 10, 3),
(4, 'Complaint', 4, 4),
(5, 'Feedback', 8, 5);
