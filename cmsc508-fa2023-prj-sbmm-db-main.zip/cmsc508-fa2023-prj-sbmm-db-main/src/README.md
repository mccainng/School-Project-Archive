# Deliverable 7. This assignment is the 7th deliverable for the semester long database project. The source code which contains deliver7-ddl.sql, api.py, and apitest.py which define our database data, api, and testing of the API.
# Running the program
* Clone the appropriate repository
* Cd into cloned repository 
* Open deliver7-ddl.sql to view SQL data, or view api.py/api.test to view API 

# Project Overview 
* View Source code files as needed.
* edit as needed.
