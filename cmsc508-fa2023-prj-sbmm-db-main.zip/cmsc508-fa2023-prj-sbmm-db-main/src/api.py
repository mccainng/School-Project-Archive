from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Define the config map for your Flask app
config_map = {
    'user': 'CMSC508_USER',
    'password': 'CMSC508_PASSWORD',
    'host': 'CMSC508_HOST',
    'database': 'SBMM_DB_NAME'
}

# Map config values from .env to Flask app config
for key, value in config_map.items():
    app.config[key] = os.getenv(value)

# Construct the SQLALCHEMY_DATABASE_URI
app.config['SQLALCHEMY_DATABASE_URI'] = (
    f"mysql+pymysql://{app.config['user']}:{app.config['password']}@{app.config['host']}/{app.config['database']}"
)

# Create the SQLAlchemy instance
db = SQLAlchemy(app)

## Define the database models

# Model for the 'Player_Info' table
class PlayerInfo(db.Model):
    __tablename__ = 'Player_Info'
    Player_Id = db.Column(db.Integer, primary_key=True)
    Player_Name = db.Column(db.String(255), nullable=False)

# Model for the 'Matchmaking_Data' table
class MatchmakingData(db.Model):
    __tablename__ = 'Matchmaking_Data'
    Match_ID = db.Column(db.Integer, primary_key=True)
    match_outcome = db.Column(db.String(255), nullable=False)
    win_loss_ratio = db.Column(db.Float, nullable=False)
    Player_Id = db.Column(db.Integer, db.ForeignKey('Player_Info.Player_Id'))

# Model for the 'Gameplay_Metrics' table
class GameplayMetrics(db.Model):
    __tablename__ = 'Gameplay_Metrics'
    Metrics_ID = db.Column(db.Integer, primary_key=True)
    playtime = db.Column(db.Integer, nullable=False)
    level = db.Column(db.Integer, nullable=False)
    Player_Id = db.Column(db.Integer, db.ForeignKey('Player_Info.Player_Id'))

# Model for the 'Interaction_Data' table.
class InteractionData(db.Model):
    __tablename__ = 'Interaction_Data'
    interaction_ID = db.Column(db.Integer, primary_key=True)
    interaction_type = db.Column(db.String(255), nullable=False)
    feedback_rating = db.Column(db.Integer, nullable=False)
    Player_Id = db.Column(db.Integer, db.ForeignKey('Player_Info.Player_Id'))

### API Routes

## Routes for PlayerInfo table

# Get all players
@app.route('/players', methods=['GET'])
def get_players():
    players_query = PlayerInfo.query
    order_by = request.args.get('order_by', default='Player_Id')
    order = request.args.get('order', default='asc')
    if order_by:
        players_query = players_query.order_by(getattr(PlayerInfo, order_by).asc() if order == 'asc' else getattr(PlayerInfo, order_by).desc())
    players = players_query.all()
    return jsonify([{'Player_Id': player.Player_Id, 'Player_Name': player.Player_Name} for player in players])

# Add a new player
@app.route('/add_player', methods=['POST'])
def add_player():
    data = request.json
    new_player = PlayerInfo(Player_Id=data['Player_Id'], Player_Name=data['Player_Name'])
    db.session.add(new_player)
    db.session.commit()
    return jsonify({'message': 'Player added successfully'})

# Get specific player by ID
@app.route('/players/<int:player_id>', methods=['GET'])
def get_player_by_id(player_id):
    player = PlayerInfo.query.get(player_id)
    if player:
        return jsonify({'Player_Id': player.Player_Id, 'Player_Name': player.Player_Name})
    else:
        return jsonify({'error': 'Player not found'}), 404

# Update player by ID
@app.route('/update_player/<int:player_id>', methods=['PUT'])
def update_player(player_id):
    player = PlayerInfo.query.get(player_id)
    if player:
        data = request.json
        player.Player_Name = data['Player_Name']
        db.session.commit()
        return jsonify({'message': 'Player updated successfully'})
    else:
        return jsonify({'error': 'Player not found'}), 404

# Delete player by ID
@app.route('/delete_player/<int:player_id>', methods=['DELETE'])
def delete_player(player_id):
    player = PlayerInfo.query.get(player_id)
    if player:
        db.session.delete(player)
        db.session.commit()
        return jsonify({'message': 'Player deleted successfully'})
    else:
        return jsonify({'error': 'Player not found'}), 404

## Routes for MatchmakingData table

# Get all matchmaking data
@app.route('/matches', methods=['GET'])
def get_matches():
    matches = MatchmakingData.query.all()
    return jsonify([{'Match_ID': match.Match_ID, 'match_outcome': match.match_outcome, 'win_loss_ratio': match.win_loss_ratio, 'Player_Id': match.Player_Id} for match in matches])

# Add new matchmaking data 
@app.route('/add_matchmaking_data', methods=['POST'])
def add_matchmaking_data():
    data = request.json
    new_matchmaking_data = MatchmakingData(Match_ID=data['Match_ID'],
                                           match_outcome=data['match_outcome'],
                                           win_loss_ratio=data['win_loss_ratio'],
                                           Player_Id=data['Player_Id'])
    db.session.add(new_matchmaking_data)
    db.session.commit()
    return jsonify({'message': 'Matchmaking data added successfully'})

# Get specific matchmaking data by ID.
@app.route('/matchmaking_data/<int:match_id>', methods=['GET'])
def get_matchmaking_data_by_id(match_id):
    match_data = MatchmakingData.query.get(match_id)
    if match_data:
        return jsonify({'Match_ID': match_data.Match_ID, 'match_outcome': match_data.match_outcome, 'win_loss_ratio': match_data.win_loss_ratio, 'Player_Id': match_data.Player_Id})
    else:
        return jsonify({'error': 'Matchmaking data not found'}), 404

# Update matchmaking data by ID
@app.route('/update_matchmaking_data/<int:match_id>', methods=['PUT'])
def update_matchmaking_data(match_id):
    match_data = MatchmakingData.query.get(match_id)
    if match_data:
        data = request.json
        match_data.match_outcome = data['match_outcome']
        match_data.win_loss_ratio = data['win_loss_ratio']
        match_data.Player_Id = data['Player_Id']
        db.session.commit()
        return jsonify({'message': 'Matchmaking data updated successfully'})
    else:
        return jsonify({'error': 'Matchmaking data not found'}), 404

# Delete matchmaking data by ID
@app.route('/delete_matchmaking_data/<int:match_id>', methods=['DELETE'])
def delete_matchmaking_data(match_id):
    match_data = MatchmakingData.query.get(match_id)
    if match_data:
        db.session.delete(match_data)
        db.session.commit()
        return jsonify({'message': 'Matchmaking data deleted successfully'})
    else:
        return jsonify({'error': 'Matchmaking data not found'}), 404

## Routes for GameplayMetrics table

# Get all gameplay metrics with optional query parameters
@app.route('/gameplay_metrics', methods=['GET'])
def get_gameplay_metrics():
    order_by = request.args.get('order_by', default='Metrics_ID')
    order = request.args.get('order', default='asc')
    limit = request.args.get('limit', type=int)
    metrics_query = GameplayMetrics.query
    if order_by:
        metrics_query = metrics_query.order_by(getattr(GameplayMetrics, order_by).asc() if order == 'asc' else getattr(GameplayMetrics, order_by).desc())
    if limit is not None:
        metrics_query = metrics_query.limit(limit)
    metrics = metrics_query.all()
    return jsonify([{'Metrics_ID': metric.Metrics_ID, 'playtime': metric.playtime, 'level': metric.level, 'Player_Id': metric.Player_Id} for metric in metrics])

# Add new gameplay metrics
@app.route('/add_gameplay_metrics', methods=['POST'])
def add_gameplay_metrics():
    data = request.json
    new_metrics = GameplayMetrics(Metrics_ID=data['Metrics_ID'],
                                  playtime=data['playtime'],
                                  level=data['level'],
                                  Player_Id=data['Player_Id'])
    db.session.add(new_metrics)
    db.session.commit()
    return jsonify({'message': 'Gameplay metrics added successfully'})

# Get specific gameplay metrics by ID
@app.route('/gameplay_metrics/<int:metrics_id>', methods=['GET'])
def get_gameplay_metrics_by_id(metrics_id):
    metrics = GameplayMetrics.query.get(metrics_id)
    if metrics:
        return jsonify({'Metrics_ID': metrics.Metrics_ID, 'playtime': metrics.playtime, 'level': metrics.level, 'Player_Id': metrics.Player_Id})
    else:
        return jsonify({'error': 'Metrics not found'}), 404

# Update gameplay metrics by ID
@app.route('/update_gameplay_metrics/<int:metrics_id>', methods=['PUT'])
def update_gameplay_metrics(metrics_id):
    metrics = GameplayMetrics.query.get(metrics_id)
    if metrics:
        data = request.json
        metrics.playtime = data['playtime']
        metrics.level = data['level']
        metrics.Player_Id = data['Player_Id']
        db.session.commit()
        return jsonify({'message': 'Gameplay metrics updated successfully'})
    else:
        return jsonify({'error': 'Metrics not found'}), 404

# Delete gameplay metrics by ID
@app.route('/delete_gameplay_metrics/<int:metrics_id>', methods=['DELETE'])
def delete_gameplay_metrics(metrics_id):
    metrics = GameplayMetrics.query.get(metrics_id)
    if metrics:
        db.session.delete(metrics)
        db.session.commit()
        return jsonify({'message': 'Gameplay metrics deleted successfully'})
    else:
        return jsonify({'error': 'Metrics not found'}), 404

## Routes for InteractionData table

# Get all interaction data with optional query parameters
@app.route('/interaction_data', methods=['GET'])
def get_interaction_data():
    interactions_query = InteractionData.query
    player_ids = request.args.getlist('Player_Id')
    if player_ids:
        interactions_query = interactions_query.filter(InteractionData.Player_Id.in_(player_ids))
    order_by = request.args.get('order_by', default='interaction_ID')
    order = request.args.get('order', default='asc')
    limit = request.args.get('limit')
    if order_by:
        interactions_query = interactions_query.order_by(getattr(InteractionData, order_by).asc() if order == 'asc' else getattr(InteractionData, order_by).desc())
    if limit:
        interactions_query = interactions_query.limit(int(limit))
    interactions = interactions_query.all()
    return jsonify([{'interaction_ID': interaction.interaction_ID, 'interaction_type': interaction.interaction_type, 'feedback_rating': interaction.feedback_rating, 'Player_Id': interaction.Player_Id} for interaction in interactions])

# Add new interaction data
@app.route('/add_interaction_data', methods=['POST'])
def add_interaction_data():
    data = request.json
    new_interaction = InteractionData(interaction_ID=data['interaction_ID'],
                                      interaction_type=data['interaction_type'],
                                      feedback_rating=data['feedback_rating'],
                                      Player_Id=data['Player_Id'])
    db.session.add(new_interaction)
    db.session.commit()
    return jsonify({'message': 'Interaction data added successfully'})

# Get specific interaction data by ID
@app.route('/interaction_data/<int:interaction_id>', methods=['GET'])
def get_interaction_data_by_id(interaction_id):
    interaction = InteractionData.query.get(interaction_id)
    if interaction:
        return jsonify({'interaction_ID': interaction.interaction_ID, 'interaction_type': interaction.interaction_type, 'feedback_rating': interaction.feedback_rating, 'Player_Id': interaction.Player_Id})
    else:
        return jsonify({'error': 'Interaction data not found'}), 404

# Update interaction data by ID
@app.route('/update_interaction_data/<int:interaction_id>', methods=['PUT'])
def update_interaction_data(interaction_id):
    interaction = InteractionData.query.get(interaction_id)
    if interaction:
        data = request.json
        interaction.interaction_type = data['interaction_type']
        interaction.feedback_rating = data['feedback_rating']
        interaction.Player_Id = data['Player_Id']
        db.session.commit()
        return jsonify({'message': 'Interaction data updated successfully'})
    else:
        return jsonify({'error': 'Interaction data not found'}), 404

# Delete interaction data by ID
@app.route('/delete_interaction_data/<int:interaction_id>', methods=['DELETE'])
def delete_interaction_data(interaction_id):
    interaction = InteractionData.query.get(interaction_id)
    if interaction:
        db.session.delete(interaction)
        db.session.commit()
        return jsonify({'message': 'Interaction data deleted successfully'})
    else:
        return jsonify({'error': 'Interaction data not found'}), 404

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
