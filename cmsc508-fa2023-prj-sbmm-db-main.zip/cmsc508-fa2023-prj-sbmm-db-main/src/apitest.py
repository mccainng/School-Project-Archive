import requests
import json

# Set the base URL for the API
base_url = 'http://127.0.0.1:5000'

## Response Helper Function

# Function to print the response
def print_response(response):
    print('Response Status Code:', response.status_code)
    print('Response JSON:')
    print(json.dumps(response.json(), indent=2))

## Add Entry Tests

# Test the /add_player endpoint (POST)
new_player_data = {'Player_Id': 6, 'Player_Name': 'Tifanny'}
response = requests.post(f'{base_url}/add_player', json=new_player_data)
print('\nPOST /add_player:')
print_response(response)

# Test the /add_matchmaking_data endpoint (POST)
new_match_data = {'Match_ID': 6, 'match_outcome': 'Win', 'win_loss_ratio': 0.5, 'Player_Id': 6}
response = requests.post(f'{base_url}/add_matchmaking_data', json=new_match_data)
print('\nPOST /add_matchmaking_data:')
print_response(response)

# Test the /add_gameplay_metrics endpoint (POST)
new_metrics_data = {'Metrics_ID': 6, 'playtime': 175, 'level': 3, 'Player_Id': 6}
response = requests.post(f'{base_url}/add_gameplay_metrics', json=new_metrics_data)
print('\nPOST /add_gameplay_metrics:')
print_response(response)

# Test the /add_interaction_data endpoint (POST)
new_interaction_data = {'interaction_ID': 6, 'interaction_type': 'Complaint', 'feedback_rating': 9, 'Player_Id': 6}
response = requests.post(f'{base_url}/add_interaction_data', json=new_interaction_data)
print('\nPOST /add_interaction_data:')
print_response(response)

## Update Entry Tests

# Test the /update_player_info/<player_id> endpoint (PUT)
update_player_data = {'Player_Name': 'Ally'}
response = requests.put(f'{base_url}/update_player/3', json=update_player_data)
print('\nPUT /update_player_info/3:')
print_response(response)

# Test the /update_matchmaking_data/<match_id> endpoint (PUT)
update_match_data = {'match_outcome': 'UpdatedOutcome', 'win_loss_ratio': 1.3, 'Player_Id': 4}
response = requests.put(f'{base_url}/update_matchmaking_data/4', json=update_match_data)
print('\nPUT /update_matchmaking_data/4:')
print_response(response)

# Test the /update_gameplay_metrics/<metrics_id> endpoint (PUT)
update_metrics_data = {'playtime': 250, 'level': 3, 'Player_Id': 2}
response = requests.put(f'{base_url}/update_gameplay_metrics/2', json=update_metrics_data)
print('\nPUT /update_gameplay_metrics/2:')
print_response(response)

# Test the /update_interaction_data/<interaction_id> endpoint (PUT)
update_interaction_data = {'interaction_type': 'NewFeedbackType', 'feedback_rating': 10, 'Player_Id': 2}
response = requests.put(f'{base_url}/update_interaction_data/2', json=update_interaction_data)
print('\nPUT /update_interaction_data/2:')
print_response(response)

## Get Entry Tests

# Test the /players endpoint (GET)
response = requests.get(f'{base_url}/players')
print('\nGET /players:')
print_response(response)

# Test the /players/<player_id> endpoint (GET)
response = requests.get(f'{base_url}/players/6')
print('\nGET /players/6:')
print_response(response)

# Test the /matches endpoint (GET)
response = requests.get(f'{base_url}/matches')
print('\nGET /matches:')
print_response(response)

# Test the /matchmaking_data/<match_id> endpoint (GET)
response = requests.get(f'{base_url}/matchmaking_data/6')
print('\nGET /matchmaking_data/6:')
print_response(response)

# Test the /gameplay_metrics endpoint (GET)
response = requests.get(f'{base_url}/gameplay_metrics')
print('\nGET /gameplay_metrics:')
print_response(response)

# Test the /gameplay_metrics/<metrics_id> endpoint (GET)
response = requests.get(f'{base_url}/gameplay_metrics/6')
print('\nGET /gameplay_metrics/6:')
print_response(response)

# Test the /interaction_data endpoint (GET)
response = requests.get(f'{base_url}/interaction_data')
print('\nGET /interaction_data:')
print_response(response)

# Test the /interaction_data/<interaction_id> endpoint (GET)
response = requests.get(f'{base_url}/interaction_data/6')
print('\nGET /interaction_data/6:')
print_response(response)

## Delete Entry Tests

# Test the /delete_player_info/<player_id> endpoint (DELETE)

# Test the /delete_matchmaking_data/<match_id> endpoint (DELETE)
response = requests.delete(f'{base_url}/delete_matchmaking_data/6')
print('\nDELETE /delete_matchmaking_data/6:')
print_response(response)

# Test the /delete_gameplay_metrics/<metrics_id> endpoint (DELETE)
response = requests.delete(f'{base_url}/delete_gameplay_metrics/6')
print('\nDELETE /delete_gameplay_metrics/6:')
print_response(response)

# Test the /delete_interaction_data/<interaction_id> endpoint (DELETE)
response = requests.delete(f'{base_url}/delete_interaction_data/6')
print('\nDELETE /delete_interaction_data/6:')
print_response(response)

response = requests.delete(f'{base_url}/delete_player/6')
print('\nDELETE /delete_player_info/6:')
print_response(response)

# Note: Make sure your Flask app is running before executing this script.

## Query Request Tests

# Query 1: What is the average level of all players?
response = requests.get(f'{base_url}/gameplay_metrics')
levels = [entry['level'] for entry in response.json()]
average_level = sum(levels) / len(levels)
print(f'\nQuery 1: Average Level of All Players: {average_level}')

# Query 2: What was the average Win-loss ratio of all players?
response = requests.get(f'{base_url}/matches')
win_loss_ratios = [entry['win_loss_ratio'] for entry in response.json()]
average_win_loss_ratio = sum(win_loss_ratios) / len(win_loss_ratios)
print(f'\nQuery 2: Average Win-Loss Ratio of All Players: {average_win_loss_ratio}')

# Query 3: What was the most common interaction type among players?
response = requests.get(f'{base_url}/interaction_data')
interaction_types = [entry['interaction_type'] for entry in response.json()]
most_common_interaction_type = max(set(interaction_types), key=interaction_types.count)
print(f'\nQuery 3: Most Common Interaction Type: {most_common_interaction_type}')

# Query 4: What was the least common interaction type among players?
response = requests.get(f'{base_url}/interaction_data')
interaction_types = [entry['interaction_type'] for entry in response.json()]
least_common_interaction_type = min(set(interaction_types), key=interaction_types.count)
print(f'\nQuery 4: Least Common Interaction Type: {least_common_interaction_type}')

# Query 5: What was the total playtime among all players?
response = requests.get(f'{base_url}/gameplay_metrics')
total_playtime = sum(entry['playtime'] for entry in response.json())
print(f'\nQuery 5: Total Playtime Among All Players: {total_playtime}')

# Query 6: What was the average playtime among players under level 5?
response = requests.get(f'{base_url}/gameplay_metrics')
playtime_under_level_5 = [entry['playtime'] for entry in response.json() if entry['level'] < 5]
average_playtime_under_level_5 = sum(playtime_under_level_5) / len(playtime_under_level_5)
print(f'\nQuery 6: Average Playtime Among Players Under Level 5: {average_playtime_under_level_5}')

# Query 7: Which players have a Win-Loss ratio above .8?
response = requests.get(f'{base_url}/matches')
players_above_08_ratio = [entry['Player_Id'] for entry in response.json() if entry['win_loss_ratio'] > 0.8]
print(f'\nQuery 7: Players with Win-Loss Ratio Above 0.8: {players_above_08_ratio}')

# Query 8: What feedback rating was provided among players with the 10 highest levels?
response = requests.get(f'{base_url}/gameplay_metrics?order_by=level&order=desc&limit=10')
highest_level_players_ids = [entry['Player_Id'] for entry in response.json()]
response = requests.get(f'{base_url}/interaction_data?Player_Id={"&Player_Id=".join(map(str, highest_level_players_ids))}')
feedback_ratings_highest_levels = [entry['feedback_rating'] for entry in response.json()]
print(f'\nQuery 8: Feedback Ratings Among Players with 10 Highest Levels: {feedback_ratings_highest_levels}')

# Query 9: What interaction types were provided among players with the 5 lowest player ID's?
response = requests.get(f'{base_url}/interaction_data?Player_Id=1&Player_Id=2&Player_Id=3&Player_Id=4&Player_Id=5')
interaction_types_lowest_ids = [entry['interaction_type'] for entry in response.json()]
print(f'\nQuery 9: Interaction Types Among Players with 5 Lowest Player ID\'s: {interaction_types_lowest_ids}')

# Query 10: What was the match outcome for the player with the highest win_loss_ratio?
response = requests.get(f'{base_url}/matches')
player_highest_win_loss_ratio = max(response.json(), key=lambda x: x['win_loss_ratio'])
print(f'\nQuery 10: Match Outcome for Player with Highest Win-Loss Ratio: {player_highest_win_loss_ratio["match_outcome"]}')

# Query 11: What was the match outcome for the player with the lowest win_loss_ratio?
response = requests.get(f'{base_url}/matches')
player_lowest_win_loss_ratio = min(response.json(), key=lambda x: x['win_loss_ratio'])
print(f'\nQuery 11: Match Outcome for Player with Lowest Win-Loss Ratio: {player_lowest_win_loss_ratio["match_outcome"]}')

# Query 12: Display a list of levels of players by increasing player id
response = requests.get(f'{base_url}/gameplay_metrics?order_by=Player_Id&order=asc')
levels_by_increasing_player_id = [(entry['Player_Id'], entry['level']) for entry in response.json()]
print(f'\nQuery 12: List of Levels of Players by Increasing Player ID: {levels_by_increasing_player_id}')

# Query 13: Did any top 10 highest level players give a feedback rating above 5?
response = requests.get(f'{base_url}/interaction_data?Player_Id={"&Player_Id=".join(map(str, highest_level_players_ids))}')
feedback_above_5_top_10_highest_levels = any(entry['feedback_rating'] > 5 for entry in response.json())
print(f'\nQuery 13: Any Top 10 Highest Level Players Gave Feedback Above 5? {feedback_above_5_top_10_highest_levels}')

# Query 14: Display the list of players by alphabetical order
response = requests.get(f'{base_url}/players?order_by=Player_Name&order=asc')
players_alphabetical_order = [(entry['Player_Id'], entry['Player_Name']) for entry in response.json()]
print(f'\nQuery 14: List of Players by Alphabetical Order: {players_alphabetical_order}')

# Query 15: What feedback was provided by the player with the lowest win_loss_ratio?
response = requests.get(f'{base_url}/interaction_data?Player_Id={player_lowest_win_loss_ratio["Player_Id"]}')
player_lowest_win_loss_ratio = response.json()[0]
print(f'\nQuery 15: Feedback by Player with Lowest Win-Loss Ratio: {player_lowest_win_loss_ratio["interaction_type"]}')

# Query 16: How many players with a level of 10 or lower gave a rating above 5?
response = requests.get(f'{base_url}/gameplay_metrics?order_by=level&order=asc&limit=10')
players_10_or_lower_ids = [entry['Player_Id'] for entry in response.json() if entry['level'] <= 10]
response = requests.get(f'{base_url}/interaction_data?Player_Id={"&Player_Id=".join(map(str, players_10_or_lower_ids))}')
players_10_or_lower_above_5_rating_count = sum(1 for entry in response.json() if entry['feedback_rating'] > 5 and entry['Player_Id'] in players_10_or_lower_ids)
print(f'\nQuery 16: Number of Players (Level 10 or Lower) with Rating Above 5: {players_10_or_lower_above_5_rating_count}')

# Query 17: What is the ID of the player with the lowest win-loss ratio?
print(f'\nQuery 17: ID of Player with Lowest Win-Loss Ratio: {player_lowest_win_loss_ratio["Player_Id"]}')

# Query 18: List the ID's in decreasing order
response = requests.get(f'{base_url}/players?order_by=Player_Id&order=desc')
player_ids_decreasing_order = [entry['Player_Id'] for entry in response.json()]
print(f'\nQuery 18: List of Player ID\'s in Decreasing Order: {player_ids_decreasing_order}')

# Query 19: What player ID is the highest level?
response = requests.get(f'{base_url}/gameplay_metrics?order_by=level&order=desc&limit=1')
player_id_highest_level = response.json()[0]['Player_Id']
print(f'\nQuery 19: Player ID with the Highest Level: {player_id_highest_level}')

# Query 20: What is the sum of the feedback rating?
response = requests.get(f'{base_url}/interaction_data')
sum_feedback_rating = sum(entry['feedback_rating'] for entry in response.json())
print(f'\nQuery 20: Sum of Feedback Ratings: {sum_feedback_rating}')