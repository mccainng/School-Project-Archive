# Deliverable 4. 
This assignment is the 4th deliverable for the semester long database project. The project domain, challenges, and proposed database solution were all provided in the deliver4.qmd file 

# Running the program
* Clone the appropriate repository
* Cd into cloned repository 
* Open deliver4.qmd

# Project Overview 
* View/Modify pitch/design video, Problem Description, Database Design, Project Management, etc as needed
* Render the file with the command "quarto render deliver4.qmd"
* edit as needed.

Pitch Video: https://vcu.mediaspace.kaltura.com/media/Noah+McCain%27s+Personal+Meeting+Room/1_gtk92bqr
Design Video: https://vcu.mediaspace.kaltura.com/media/Noah+McCain%27s+Zoom+Meeting/1_rfx6ozcr 
Github repo: https://github.com/cmsc-vcu/cmsc508-fa2023-prj-sbmm-db.git

# Deliverable 7. 
This assignment is the 7th deliverable for the semester long database project. The project domain, challenges, and proposed database solution, API definition, Implementation, and Refelctions are all provided in the deliver7.qmd file

# Running the program
* Clone the appropriate repository
* Cd into cloned repository 
* Open deliver7.qmd

# Project Overview 
* View/Modify final design video, Problem Description, Database Design, Project Management, API Solution, Implementation, and reflections as needed.
* Render the file with the command "quarto render deliver7.qmd"
* edit as needed.
