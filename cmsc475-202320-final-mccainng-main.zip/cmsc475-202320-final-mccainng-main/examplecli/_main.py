import click

@click.command()
def cli():
    click.echo("hello world!")
