import click
import psutil
import platform

if platform.system() == "Windows":
    import pycaw.pycaw as pycaw
else:
    import os

def get_system_info():
    # Get battery percentage
    battery = psutil.sensors_battery()
    plugged = battery.power_plugged
    percent = battery.percent
    
    if plugged:
        status = "charging"
    else:
        status = "discharging"
    
    # Get volume level
    if platform.system() == "Windows":
        sessions = pycaw.AudioUtilities.GetAllSessions()
        volume = 0
        for session in sessions:
            volume += session.SimpleAudioVolume.GetMasterVolume()
        volume /= len(sessions)
        volume = int(volume * 100)
    else:
        volume = os.popen("amixer get Master | awk '/%/ {print $4}' | tr -d '[]%'").read().strip()
    
    # Print system info
    print("Battery:", percent, status)
    print("Volume:", str(volume) + "%")

get_system_info()





@click.command()
def cli():
    click.echo("hello world! from cli3")
