import click
import random
import string

def generate_password(length=8, has_numbers=True, has_letters=True, has_symbols=False):
    """Generates a random password with the specified parameters.
    
    Args:
        length (int): The length of the password.
        has_numbers (bool): Whether to include numbers in the password.
        has_letters (bool): Whether to include letters in the password.
        has_symbols (bool): Whether to include symbols in the password.
    
    Returns:
        A string containing the randomly generated password.
    """
    characters = ""
    if has_numbers:
        characters += string.digits
    if has_letters:
        characters += string.ascii_letters
    if has_symbols:
        characters += string.punctuation
    
    if len(characters) == 0:
        raise ValueError("At least one character category should be selected.")
    
    password = ""
    for _ in range(length):
        password += random.choice(characters)
    
    return password


# Generate a password with default settings (8 characters, letters and numbers)
password1 = generate_password()
print(password1)

# Generate a password with 12 characters, letters, numbers and symbols
password2 = generate_password(length=12, has_numbers=True, has_letters=True, has_symbols=True)
print(password2)

# Generate a password with only numbers
password3 = generate_password(length=6, has_numbers=True, has_letters=False, has_symbols=False)
print(password3)

# Generate a password with only symbols
password4 = generate_password(length=10, has_numbers=False, has_letters=False, has_symbols=True)
print(password4)
# Generate a password with default settings (8 characters, letters and numbers)
password5 = generate_password()
print(password1)

# Generate a password with 12 characters, letters, numbers and symbols
password6 = generate_password(length=12, has_numbers=True, has_letters=True, has_symbols=True)
print(password2)

# Generate a password with only numbers
password7 = generate_password(length=6, has_numbers=True, has_letters=False, has_symbols=False)
print(password3)

# Generate a password with only symbols
password8 = generate_password(length=10, has_numbers=False, has_letters=False, has_symbols=True)
print(password4)


@click.command()
def cli():
    click.echo("hello world! from cli1")
