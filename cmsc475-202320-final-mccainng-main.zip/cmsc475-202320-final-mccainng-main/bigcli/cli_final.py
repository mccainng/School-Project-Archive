""" module final.py
"""
import os
import click
from loguru import logger
from bigcli import click_config_file,myprovider

logger.trace(f"After imports {__file__}")

@click.command()
@click.option('--test',  default="test string in click.option", help='reading a string')
@click_config_file.configuration_option(implicit=True,provider=myprovider)
#@click_config_file.configuration_option()
def cli(test):
    """ help for final  """
    logger.info("Entering command check")
    click.echo(f"parameter test: {test}" )
    click.echo(f"current folder:{os.getcwd()}")

if __name__ == '__main__':
    cli() # pylint: disable=no-value-for-parameter # pragma: no cover
