""" module cli4.py
"""
import os
import click
from loguru import logger
from bigcli import click_config_file,myprovider
import ctypes




def set_wallpaper(image_path):
    SPI_SETDESKWALLPAPER = 20
    ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, image_path, 3)

    
set_wallpaper("C:\\Users\\Owner\\projects\\cmsc475-202320-final-mccainng\\bigcli\\Background.jpg")

logger.trace(f"After imports {__file__}")



@click.command()
@click.option('--test',  default="test string in click.option", help='reading a string')
@click_config_file.configuration_option(implicit=True,provider=myprovider)

#@click_config_file.configuration_option()


def cli(test):
    """ The cli4 command changes the background based on the image to the specificed path  """
    logger.info("Entering command check")
    click.echo(f"parameter test: {test}" )
    click.echo(f"current folder:{os.getcwd()}")

if __name__ == '__main__':
    cli() # pylint: disable=no-value-for-parameter # pragma: no cover