""" module cli5.py
"""
import os
import click
from loguru import logger
from bigcli import click_config_file,myprovider
import requests

def get_weather(api_key, city):
    api_url = f"http://api.weatherapi.com/v1/current.json?key={api_key}&q={city}"
    response = requests.get(api_url)

    if response.status_code != 200:
        print("Error connecting to Weather API.")
        return None

    data = response.json()
    temp_c = data["current"]["temp_c"]
    condition = data["current"]["condition"]["text"]

    return f"The current temperature in {city} is {temp_c}°C with {condition}."

# Example usage
api_key = "5ed3cd2a3fea46d8bff00022230805"
city = "Richmond"
result = get_weather(api_key, city)
print(result)




logger.trace(f"After imports {__file__}")


@click.command()
@click.option('--test',  default="test string in click.option", help='reading a string')
@click_config_file.configuration_option(implicit=True,provider=myprovider)
#@click_config_file.configuration_option()
def cli(test):
    """ The cli5 command returns the weather for the current city and current conditions """
    logger.info("Entering command check")
    click.echo(f"parameter test: {test}" )
    click.echo(f"current folder:{os.getcwd()}")

if __name__ == '__main__':
    cli() # pylint: disable=no-value-for-parameter # pragma: no cover
