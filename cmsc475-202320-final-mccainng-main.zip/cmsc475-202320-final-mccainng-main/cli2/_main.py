import click
import random

def generate_motivational_message():
    messages = [
        "Believe you can and you're halfway there. -Theodore Roosevelt",
        "You are never too old to set another goal or to dream a new dream. -C.S. Lewis",
        "Success is not final, failure is not fatal: It is the courage to continue that counts. -Winston Churchill",
        "Don't watch the clock; do what it does. Keep going. -Sam Levenson",
        "Believe in yourself! Have faith"
    ]
    message = random.choice(messages)
    print(message)

# call the function to generate a message
generate_motivational_message()



@click.command()
def cli():
    click.echo("hello world! from cli2")
