#Noah McCain
#10/17/2023
#CMSC455
#Assignment 3

from flask import Flask, render_template, request
from flask_bootstrap import Bootstrap

app = Flask(__name__)
bootstrap = Bootstrap(app)

@app.route('/', methods=['GET', 'POST'])
def course_override():
    if request.method == 'POST':
        student_name = request.form.get('student_name')
        student_email = request.form.get('student_email')
        course_name = request.form.get('course_name')

        if not (student_name and course_name ):
            return render_template('index.html', error="Please fill out all the required fields.")

        return render_template('success.html')

    return render_template('index.html')

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'),500

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'),404


if __name__ == '__main__':
    app.run(debug=True)


