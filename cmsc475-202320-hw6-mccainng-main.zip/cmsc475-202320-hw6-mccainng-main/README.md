# Homework 6 - Creating mobile interfaces

Finally, we get to code!  Here is a link to the homework instructions:

- <https://lowkeylabs.github.io/cmsc475-202320-materials/homework6.html>

## Submission

YOU should edit this README.md file and update the links as appropriate.


## Your source code (deliverable)
 -- https://github.com/cmsc-vcu/cmsc475-202320-hw6-mccainng/blob/8ad3928f9d1be4a7d9a0ab1567c79849ba3a7476/App.js

--  https://github.com/cmsc-vcu/cmsc475-202320-hw6-mccainng/blob/08401264d83544819da60549fd476f9b64d324d5/MyScreen.js

 -- https://github.com/cmsc-vcu/cmsc475-202320-hw6-mccainng/blob/af84864cdf283ca05b8f120a6465f9aa4dc223c7/globalStyles.js


## Video (deliverable)


https://user-images.githubusercontent.com/123034463/227793843-af5485ed-7426-4541-aaa1-201949563945.MP4


## URL of prototype (deliverable)

[https://www.figma.com/file/V3lJ9njGOSUcbEyU3fWuTQ/Prototype?node-id=0%3A1&t=IuagU6Anp9qtJbvE-1]


