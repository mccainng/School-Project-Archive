import React, {useState} from 'react';

import { StatusBar } from 'expo-status-bar';
import { Pressable, StyleSheet, Text, View, Image, Modal,ImageBackground} from 'react-native';
import {Card } from 'react-native-elements';


import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { Screen1 } from './pages/MyScreen';
import {styles} from './globalStyles';


const Tab = createBottomTabNavigator();



function Screen2() {
  return (
    <View style={styles.container}>
      <Card>
      <Image style={styles.ImageStyle} source={require("./assets/Richmond.jpg")} />

      </Card>
      <Text>Ken</Text> 
    </View>
  );
}

export default function App() {
  return (
   <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Screen1" component={Screen1} />
        <Tab.Screen name="Screen2" component={Screen2} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

  





