import React, {useState} from 'react';
import { Pressable, StyleSheet, Text, View, Image, Modal,ImageBackground} from 'react-native';
import {Card } from 'react-native-elements';
import {styles} from '../globalStyles'

var database = [ 
    {id: "0", name: "Lebron", image:require("../assets/bron.jpg")},
    {id: "1", name: "Kendrick", image:require("../assets/ken.jpg")},
    {id: "2", name: "Drake", image:require("../assets/Drake.jpg")},
    {id: "3", name: "Jay - Z", image:require("../assets/z.webp")},
    {id: "4", name: "Morgan Freeman", image:require("../assets/Morgan-Freeman.webp")},
    {id: "5", name: "Samuel-L-Jackson", image:require("../assets/Samuel-L-Jackson.webp")},    
];

function MyButton( props ){
  return (
    <Pressable
       onPress={() => {
         props.onPressed();
       }}
       style={({pressed}) => [
         {
           backgroundColor: pressed ? 'darkcyan' : '#BEBEBE',
         },
         styles.wrapperCustom,
       ]}>
       {({pressed}) => (
         <Text style={styles.text}>{ props.name }</Text>
       )}
     </Pressable>        
   );
}

export function Screen1() {
  const bg = require("../assets/vcu.jpg");
  const [timesPressed, setTimesPressed ] = useState(0);
  const [ imageId, setImageId ] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);
  const [ guess, setGuess ] = useState( imageId );

  function DoMe( i ){

    setGuess( i );
    if (imageId==i){
      setModalVisible( false );

      setImageId( Math.floor(Math.random() * database.length ) );
    } else {
      setModalVisible( true );
    }
  }

  return (
    <View style={styles.container}>
      <Image style={styles.background} source={bg} />

      <Card>
        <Image style={styles.cartoon} source={database[imageId].image} />
      </Card>

      

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert('Modal has been closed.');
          setModalVisible(!modalVisible);
      }}>
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Text style={styles.modalText}>Incorrect!</Text>
            <Pressable
              style={[styles.button, styles.buttonClose]}
              onPress={() => {
                 setModalVisible(!modalVisible);
              } }>
              <Text style={styles.textStyle}>Try Again!</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
      <View style={{flex: 0, flexDirection:"row", flexWrap:"wrap",justifyContent:"center"}}>
          { database.map( (item)=>{
              return (
              <MyButton onPressed={()=>DoMe( item.id )} key={item.id} name={item.name} id={item.id} />
              );
          })}
      </View>
    </View>
  );
  
}
    
  

 