import requests
import json
import pytest

def test_shuffle_endpoint():
    base_url = 'http://host.docker.internal:5000'
    endpoint = '/shuffle'

    input_list = [1, 2, 3, 4, 5]

    response = requests.get(f'{base_url}{endpoint}', json={'list_of_ints': input_list})
    assert response.status_code == 200
    response_data = response.json()
    assert 'shuffled_num' in response_data, "The response is missing the 'shuffled_num'"
    shuffled_list = response_data['shuffled_num']
    assert input_list != shuffled_list, "The list is not shuffled"

if __name__ == '__main__':
    pytest.main(['test_app.py'])
