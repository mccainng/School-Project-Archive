from flask import Flask, request, jsonify
import random

app = Flask(__name__)

@app.route('/shuffle', methods=['GET'])
def shuffle():
   try:
        data = request.get_json()
        input_list = data['list_of_ints']
        shuffled_num = random.sample(input_list, len(input_list))
        response = {'shuffled_num': shuffled_num}
        return jsonify(response)
   
   except Exception as e:
       error = {'error': str(e)}
       return jsonify(error), 400
   
if __name__ == '__main__':
    app.run(debug=True)


    

